/*******************************************************************************
* KindEditor - WYSIWYG HTML Editor for Internet
* Copyright (C) 2006-${THISYEAR} kindsoft.net
*
* @author Roddy <luolonghao@gmail.com>
* @website http://www.kindsoft.net/
* @licence http://www.kindsoft.net/license.php
* @version ${VERSION}
*******************************************************************************/

(function (window, undefined) {

	if (window.KindEditor) {
		return;
	}
